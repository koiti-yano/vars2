#' irf: generic function
#' @export
"irf" <- function(x, ...){
  UseMethod("irf")
}

